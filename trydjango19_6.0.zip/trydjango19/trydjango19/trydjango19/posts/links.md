20. https://www.youtube.com/watch?v=-8YN3_nlUFY&list=PLEsfXFp6DpzQB82YbmKKBy2jKdzpZKczn&index=20
Digital marketplace = https://www.codingforentrepreneurs.com/projects/digital-marketplace
Most common regular expressions = https://github.com/codingforentrepreneurs/Guides/blob/master/all/common_url_regex.md
Boot strap = https://getbootstrap.com/
Pagination = https://docs.djangoproject.com/en/3.0/topics/pagination/
Sharelinks = https://github.com/codingforentrepreneurs/Guides/blob/master/all/social_share_links.md
Comment Pluggin = https://developers.facebook.com/docs/plugins/comments
Q Look ups = https://docs.djangoproject.com/en/3.0/topics/db/queries/
Markdown Cheatsheet = https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet
JQuery = https://code.jquery.com/ - For markdown installation
Markdown Source = https://github.com/markedjs/marked => https://cdnjs.com/libraries/marked
Page down = https://github.com/timmyomahony/django-pagedown
Markdown deux = https://github.com/trentm/django-markdown-deux
Build in template tags and filter = https://docs.djangoproject.com/en/3.0/ref/templates/builtins/
Advancing forms =  https://django-crispy-forms.readthedocs.io/en/latest/
Input groups = https://getbootstrap.com/docs/4.0/components/input-group/
Font Awesome = https://fontawesome.com/icons/search?style=solid&from=io
Font Awesome cdn = https://www.bootstrapcdn.com/fontawesome/
Comments Blockquotes= https://getbootstrap.com/docs/4.0/content/typography/#blockquotes
Built ins = https://docs.djangoproject.com/en/3.0/ref/templates/builtins/#date